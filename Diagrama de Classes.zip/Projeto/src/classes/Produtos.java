package classes;

public class Produtos {

	public String marca;
	public String altura;
	public String peso;
	public String volume;
	public String potencia;
	public String codigo;
	public String garantia;
    public String preco;
    
	public Produtos(String marca, String altura, String peso, String volume, String potencia, String codigo,
			String garantia, String preco) {
		this.marca = marca;
		this.altura = altura;
		this.peso = peso;
		this.volume = volume;
		this.potencia = potencia;
		this.codigo = codigo;
		this.garantia = garantia;
		this.preco = preco;
		
	}
   
}